package com.example.lgremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TvClient(applicationContext)
        setContent { MaterialTheme { App(tv) } }
    }
}

@Composable
fun Key(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier.height(56.dp),
        contentPadding = PaddingValues(4.dp)
    ) { Text(label, fontSize = 16.sp, maxLines = 1) }
}

@Composable
fun RowOf(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun App(tv: TvClient) {
    var ip by remember { mutableStateOf(tv.savedIp) }
    var mac by remember { mutableStateOf(tv.savedMac) }
    val w = Modifier.weight(1f)

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(tv.status, style = MaterialTheme.typography.titleMedium)

            if (!tv.connected) {
                OutlinedTextField(
                    value = ip, onValueChange = { ip = it }, singleLine = true,
                    label = { Text("כתובת IP של הטלוויזיה") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { tv.discover() }, modifier = Modifier.fillMaxWidth()) {
                    Text("חפש טלוויזיה ברשת")
                }
                tv.found.forEach { f ->
                    OutlinedButton(onClick = { ip = f }, modifier = Modifier.fillMaxWidth()) { Text(f) }
                }
                Button(onClick = { tv.connect(ip) }, modifier = Modifier.fillMaxWidth()) {
                    Text("התחבר")
                }
                OutlinedTextField(
                    value = mac, onValueChange = { mac = it }, singleLine = true,
                    label = { Text("כתובת MAC (להדלקה מרחוק)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { tv.savedMac = mac; tv.wake(mac) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("הדלק טלוויזיה") }
            } else {
                RowOf {
                    Key("כיבוי", w) { tv.request("ssap://system/turnOff") }
                    Key("השתק", w) { tv.toggleMute() }
                }
                RowOf { Spacer(w); Key("▲", w) { tv.button("UP") }; Spacer(w) }
                RowOf {
                    Key("◀", w) { tv.button("LEFT") }
                    Key("OK", w) { tv.button("ENTER") }
                    Key("▶", w) { tv.button("RIGHT") }
                }
                RowOf { Spacer(w); Key("▼", w) { tv.button("DOWN") }; Spacer(w) }
                RowOf {
                    Key("חזרה", w) { tv.button("BACK") }
                    Key("בית", w) { tv.button("HOME") }
                    Key("יציאה", w) { tv.button("EXIT") }
                }
                RowOf {
                    Key("קול +", w) { tv.request("ssap://audio/volumeUp") }
                    Key("ערוץ +", w) { tv.request("ssap://tv/channelUp") }
                }
                RowOf {
                    Key("קול −", w) { tv.request("ssap://audio/volumeDown") }
                    Key("ערוץ −", w) { tv.request("ssap://tv/channelDown") }
                }
                RowOf {
                    Key("⏪", w) { tv.request("ssap://media.controls/rewind") }
                    Key("▶️", w) { tv.request("ssap://media.controls/play") }
                    Key("⏸", w) { tv.request("ssap://media.controls/pause") }
                    Key("⏩", w) { tv.request("ssap://media.controls/fastForward") }
                }
                RowOf {
                    Key("Netflix", w) { tv.launch("netflix") }
                    Key("YouTube", w) { tv.launch("youtube.leanback.v4") }
                }
                RowOf {
                    Key("Prime", w) { tv.launch("amazon") }
                    Key("Disney+", w) { tv.launch("com.disney.disneyplus-prod") }
                }
                OutlinedButton(onClick = { tv.disconnect() }, modifier = Modifier.fillMaxWidth()) {
                    Text("התנתק")
                }
            }
        }
    }
}
