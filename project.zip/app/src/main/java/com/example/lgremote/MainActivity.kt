package com.example.lgremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TvClient(applicationContext)
        setContent { MaterialTheme { App(tv) } }
    }
}

@Composable
fun RowScope.Key(label: String, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = Modifier.weight(1f).height(56.dp),
        contentPadding = PaddingValues(4.dp)
    ) { Text(label, fontSize = 16.sp, maxLines = 1) }
}

@Composable
fun RowScope.Gap() {
    Spacer(Modifier.weight(1f))
}

@Composable
fun RowOf(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun App(tv: TvClient) {
    var ip by remember { mutableStateOf(tv.savedIp) }
    var mac by remember { mutableStateOf(tv.savedMac) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(tv.status, style = MaterialTheme.typography.titleMedium)

            if (!tv.connected) {
                OutlinedTextField(
                    value = ip, onValueChange = { ip = it }, singleLine = true,
                    label = { Text("כתובת IP של הטלוויזיה") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { tv.discover() }, modifier = Modifier.fillMaxWidth()) {
                    Text("חפש טלוויזיה ברשת")
                }
                tv.found.forEach { f ->
                    OutlinedButton(onClick = { ip = f }, modifier = Modifier.fillMaxWidth()) { Text(f) }
                }
                Button(onClick = { tv.connect(ip) }, modifier = Modifier.fillMaxWidth()) {
                    Text("התחבר")
                }
                OutlinedTextField(
                    value = mac, onValueChange = { mac = it }, singleLine = true,
                    label = { Text("כתובת MAC (להדלקה מרחוק)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { tv.savedMac = mac; tv.wake(mac) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("הדלק טלוויזיה") }
            } else {
                RowOf {
                    Key("כיבוי") { tv.request("ssap://system/turnOff") }
                    Key("השתק") { tv.toggleMute() }
                }
                RowOf { Gap(); Key("▲") { tv.button("UP") }; Gap() }
                RowOf {
                    Key("◀") { tv.button("LEFT") }
                    Key("OK") { tv.button("ENTER") }
                    Key("▶") { tv.button("RIGHT") }
                }
                RowOf { Gap(); Key("▼") { tv.button("DOWN") }; Gap() }
                RowOf {
                    Key("חזרה") { tv.button("BACK") }
                    Key("בית") { tv.button("HOME") }
                    Key("יציאה") { tv.button("EXIT") }
                }
                RowOf {
                    Key("קול +") { tv.request("ssap://audio/volumeUp") }
                    Key("ערוץ +") { tv.request("ssap://tv/channelUp") }
                }
                RowOf {
                    Key("קול −") { tv.request("ssap://audio/volumeDown") }
                    Key("ערוץ −") { tv.request("ssap://tv/channelDown") }
                }
                RowOf {
                    Key("⏪") { tv.request("ssap://media.controls/rewind") }
                    Key("▶️") { tv.request("ssap://media.controls/play") }
                    Key("⏸") { tv.request("ssap://media.controls/pause") }
                    Key("⏩") { tv.request("ssap://media.controls/fastForward") }
                }
                RowOf {
                    Key("Netflix") { tv.launch("netflix") }
                    Key("YouTube") { tv.launch("youtube.leanback.v4") }
                }
                RowOf {
                    Key("Prime") { tv.launch("amazon") }
                    Key("Disney+") { tv.launch("com.disney.disneyplus-prod") }
                }
                OutlinedButton(onClick = { tv.disconnect() }, modifier = Modifier.fillMaxWidth()) {
                    Text("התנתק")
                }
            }
        }
    }
}
