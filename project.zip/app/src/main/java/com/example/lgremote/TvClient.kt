package com.example.lgremote

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

class TvClient(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("lg", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    var status by mutableStateOf("לא מחובר")
        private set
    var connected by mutableStateOf(false)
        private set
    val found = mutableStateListOf<String>()

    var savedIp: String
        get() = prefs.getString("ip", "") ?: ""
        set(v) { prefs.edit().putString("ip", v).apply() }
    var savedMac: String
        get() = prefs.getString("mac", "") ?: ""
        set(v) { prefs.edit().putString("mac", v).apply() }

    private var ws: WebSocket? = null
    private var pointerWs: WebSocket? = null
    private var muted = false

    // הטלוויזיה משתמשת בתעודה self-signed, לכן מקבלים אותה (שימוש ברשת ביתית בלבד)
    private val trustAll = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    private val http: OkHttpClient = OkHttpClient.Builder().apply {
        val ssl = SSLContext.getInstance("TLS")
        ssl.init(null, arrayOf(trustAll), SecureRandom())
        sslSocketFactory(ssl.socketFactory, trustAll)
        hostnameVerifier { _, _ -> true }
        pingInterval(20, TimeUnit.SECONDS)
        connectTimeout(5, TimeUnit.SECONDS)
    }.build()

    private fun ui(block: () -> Unit) { main.post { block() } }

    // ---------- חיבור ----------
    fun connect(ip: String) {
        val host = ip.trim()
        if (host.isEmpty()) return
        savedIp = host
        open(host, true)
    }

    private fun open(host: String, secure: Boolean) {
        ws?.cancel(); pointerWs?.cancel(); pointerWs = null
        ui { connected = false; status = "מתחבר..." }
        val url = if (secure) "wss://$host:3001" else "ws://$host:3000"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { register(webSocket) }
            override fun onMessage(webSocket: WebSocket, text: String) {
                if (webSocket === ws) handle(text)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (webSocket !== ws) return
                if (secure) open(host, false)
                else ui { connected = false; status = "החיבור נכשל: ${t.message}" }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (webSocket === ws) ui { connected = false; status = "החיבור נסגר" }
            }
        })
    }

    fun disconnect() {
        ws?.cancel(); pointerWs?.cancel()
        ws = null; pointerWs = null
        ui { connected = false; status = "לא מחובר" }
    }

    private fun register(w: WebSocket) {
        val perms = listOf(
            "LAUNCH", "LAUNCH_WEBAPP", "APP_TO_APP", "CONTROL_AUDIO", "CONTROL_POWER",
            "CONTROL_DISPLAY", "CONTROL_INPUT_TV", "CONTROL_INPUT_MEDIA_PLAYBACK",
            "CONTROL_INPUT_MEDIA_RECORDING", "CONTROL_MOUSE_AND_KEYBOARD",
            "CONTROL_INPUT_JOYSTICK", "CONTROL_INPUT_TEXT", "READ_INSTALLED_APPS",
            "READ_CURRENT_CHANNEL", "READ_TV_CHANNEL_LIST", "READ_RUNNING_APPS"
        )
        val manifest = JSONObject()
            .put("manifestVersion", 1)
            .put("permissions", JSONArray(perms))
        val payload = JSONObject()
            .put("forcePairing", false)
            .put("pairingType", "PROMPT")
            .put("manifest", manifest)
        val key = prefs.getString("key", "") ?: ""
        if (key.isNotEmpty()) payload.put("client-key", key)
        w.send(
            JSONObject().put("type", "register").put("id", "register_0")
                .put("payload", payload).toString()
        )
    }

    private fun handle(text: String) {
        val j = try { JSONObject(text) } catch (e: Exception) { return }
        val type = j.optString("type")
        val id = j.optString("id")
        val p = j.optJSONObject("payload")
        when {
            type == "registered" -> {
                p?.optString("client-key")?.takeIf { it.isNotEmpty() }?.let {
                    prefs.edit().putString("key", it).apply()
                }
                ui { connected = true; status = "מחובר" }
                request("ssap://com.webos.service.networkinput/getPointerInputSocket", null, "ptr")
            }
            type == "response" && p?.has("pairingType") == true ->
                ui { status = "אשר את החיבור על מסך הטלוויזיה (לחץ כן/OK)" }
            type == "response" && id == "ptr" ->
                p?.optString("socketPath")?.takeIf { it.isNotEmpty() }?.let { openPointer(it) }
            type == "error" -> ui { status = "שגיאה: ${j.optString("error")}" }
        }
    }

    private fun openPointer(url: String) {
        pointerWs?.cancel()
        pointerWs = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {})
    }

    // ---------- פקודות ----------
    fun request(uri: String, payload: JSONObject? = null, id: String = UUID.randomUUID().toString()) {
        val m = JSONObject().put("type", "request").put("id", id).put("uri", uri)
        if (payload != null) m.put("payload", payload)
        ws?.send(m.toString())
    }

    /** כפתורי ניווט: UP, DOWN, LEFT, RIGHT, ENTER, BACK, HOME, EXIT */
    fun button(name: String) { pointerWs?.send("type:button\nname:$name\n\n") }

    fun launch(appId: String) =
        request("ssap://system.launcher/launch", JSONObject().put("id", appId))

    fun toggleMute() {
        muted = !muted
        request("ssap://audio/setMute", JSONObject().put("mute", muted))
    }

    // ---------- גילוי אוטומטי (SSDP) ----------
    fun discover() {
        ui { found.clear(); status = "מחפש טלוויזיה ברשת..." }
        Thread {
            val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lock = wifi.createMulticastLock("lgremote").apply {
                setReferenceCounted(false); acquire()
            }
            try {
                DatagramSocket().use { s ->
                    s.soTimeout = 1000
                    val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 3\r\n" +
                        "ST: urn:lge-com:service:webos-second-screen:1\r\n\r\n").toByteArray()
                    val group = InetAddress.getByName("239.255.255.250")
                    repeat(2) { s.send(DatagramPacket(msg, msg.size, group, 1900)) }
                    val end = System.currentTimeMillis() + 5000
                    val buf = ByteArray(2048)
                    while (System.currentTimeMillis() < end) {
                        try {
                            val p = DatagramPacket(buf, buf.size)
                            s.receive(p)
                            val ip = p.address.hostAddress ?: continue
                            ui { if (ip !in found) found.add(ip) }
                        } catch (e: SocketTimeoutException) {
                        }
                    }
                }
            } catch (e: Exception) {
                ui { status = "שגיאת חיפוש: ${e.message}" }
            } finally {
                lock.release()
            }
            ui { status = if (found.isEmpty()) "לא נמצאה טלוויזיה. הקלד IP ידנית" else "נמצאו ${found.size} מכשירים" }
        }.start()
    }

    // ---------- הדלקה (Wake-on-LAN) ----------
    fun wake(mac: String) {
        Thread {
            try {
                val b = mac.trim().split(":", "-").map { it.toInt(16).toByte() }.toByteArray()
                require(b.size == 6)
                val data = ByteArray(6) { 0xFF.toByte() } + ByteArray(96) { b[it % 6] }
                DatagramSocket().use {
                    it.broadcast = true
                    it.send(DatagramPacket(data, data.size, InetAddress.getByName("255.255.255.255"), 9))
                }
                ui { status = "נשלחה פקודת הדלקה" }
            } catch (e: Exception) {
                ui { status = "כתובת MAC לא תקינה (פורמט: AA:BB:CC:DD:EE:FF)" }
            }
        }.start()
    }
}
